# Rename this file to config.py and fill in your own values.
# Never commit your real config.py or client_secret.json to GitHub!

# Path to the OAuth client secret file downloaded from Google Cloud Console
CLIENT_SECRETS_FILE = "client_secret.json"

# Scopes required for uploading videos and reading analytics
SCOPES = [
    "https://www.googleapis.com/auth/youtube.upload",
    "https://www.googleapis.com/auth/youtube.readonly",
    "https://www.googleapis.com/auth/yt-analytics.readonly",
]

# Default video privacy status: "public", "private", or "unlisted"
DEFAULT_PRIVACY_STATUS = "private"

# Default category ID (22 = People & Blogs). Full list:
# https://developers.google.com/youtube/v3/docs/videoCategories/list
DEFAULT_CATEGORY_ID = "22"

# Default channel handle (used for analytics lookups)
CHANNEL_HANDLE = "@your_channel_handle"
