"""
auth.py
--------
Handles Google OAuth2 authentication for the YouTube Data API.

On first run, this opens a browser window asking the user to log in
with their Google account and grant permission. The resulting token
is cached in `token.json` so future runs don't require re-login.
"""

import os
import pickle

from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

import config

TOKEN_FILE = "token.json"


def get_authenticated_service():
    """
    Returns an authenticated YouTube API client (googleapiclient Resource).
    Reuses a cached token if available, otherwise runs the OAuth2 flow.
    """
    credentials = None

    if os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE, "rb") as token:
            credentials = pickle.load(token)

    if not credentials or not credentials.valid:
        if credentials and credentials.expired and credentials.refresh_token:
            credentials.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                config.CLIENT_SECRETS_FILE, config.SCOPES
            )
            credentials = flow.run_local_server(port=0)

        with open(TOKEN_FILE, "wb") as token:
            pickle.dump(credentials, token)

    return build("youtube", "v3", credentials=credentials)
