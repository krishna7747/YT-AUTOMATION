"""
uploader.py
-----------
Uploads a local video file to YouTube along with its metadata
(title, description, tags, category, privacy status) using the
YouTube Data API's `videos.insert` endpoint.
"""

from googleapiclient.http import MediaFileUpload

import config
from src.auth import get_authenticated_service


def upload_video(file_path, title, description, tags=None, privacy_status=None, category_id=None):
    """
    Uploads a video to the authenticated user's YouTube channel.

    Args:
        file_path (str): Path to the video file (.mp4, .mov, etc.)
        title (str): Video title.
        description (str): Video description.
        tags (list[str]): List of SEO tags. Defaults to empty list.
        privacy_status (str): "public", "private", or "unlisted".
        category_id (str): YouTube category ID.

    Returns:
        dict: The API response containing the uploaded video's ID and details.
    """
    youtube = get_authenticated_service()

    body = {
        "snippet": {
            "title": title,
            "description": description,
            "tags": tags or [],
            "categoryId": category_id or config.DEFAULT_CATEGORY_ID,
        },
        "status": {
            "privacyStatus": privacy_status or config.DEFAULT_PRIVACY_STATUS,
        },
    }

    media = MediaFileUpload(file_path, chunksize=-1, resumable=True)

    request = youtube.videos().insert(
        part="snippet,status",
        body=body,
        media_body=media,
    )

    response = None
    print(f"Uploading '{title}'...")
    while response is None:
        status, response = request.next_chunk()
        if status:
            print(f"  Upload progress: {int(status.progress() * 100)}%")

    print(f"Upload complete! Video ID: {response['id']}")
    return response
