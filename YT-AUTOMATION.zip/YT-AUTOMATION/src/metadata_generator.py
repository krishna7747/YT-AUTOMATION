"""
metadata_generator.py
----------------------
Generates SEO-friendly video titles, descriptions, and tags
from a topic and a list of keywords, using simple templates.

This keeps every upload consistent in style without having to
write metadata by hand each time.
"""

TITLE_TEMPLATES = [
    "{topic} - Complete Guide {year}",
    "How to {topic} (Step by Step)",
    "{topic} Explained in 5 Minutes",
    "Master {topic} Today!",
]

DESCRIPTION_TEMPLATE = """\
In this video, we cover {topic} in detail.

🔑 Keywords: {keywords}

👍 If this helped you, please like and subscribe for more content like this!
📩 Questions? Drop a comment below.

#{hashtag}
"""


def generate_metadata(topic: str, keywords: list, year: int = 2026) -> dict:
    """
    Builds a title, description, and tag list for a video.

    Args:
        topic (str): Main subject of the video.
        keywords (list[str]): Related keywords for SEO tags.
        year (int): Year to insert into title templates.

    Returns:
        dict: {"title": str, "description": str, "tags": list[str]}
    """
    title = TITLE_TEMPLATES[0].format(topic=topic, year=year)

    description = DESCRIPTION_TEMPLATE.format(
        topic=topic,
        keywords=", ".join(keywords),
        hashtag=topic.replace(" ", ""),
    )

    tags = list({*keywords, topic.lower()})

    return {
        "title": title,
        "description": description,
        "tags": tags,
    }
