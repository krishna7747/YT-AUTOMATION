"""
analytics.py
------------
Fetches basic channel and video statistics (views, likes,
subscriber count, comment count) using the YouTube Data API.
"""

from src.auth import get_authenticated_service


def get_channel_stats(channel_id: str) -> dict:
    """
    Returns subscriber count, view count, and video count for a channel.
    """
    youtube = get_authenticated_service()

    response = youtube.channels().list(
        part="statistics,snippet",
        id=channel_id,
    ).execute()

    if not response.get("items"):
        raise ValueError(f"No channel found with ID: {channel_id}")

    item = response["items"][0]
    stats = item["statistics"]

    return {
        "channel_name": item["snippet"]["title"],
        "subscribers": stats.get("subscriberCount"),
        "total_views": stats.get("viewCount"),
        "video_count": stats.get("videoCount"),
    }


def get_video_stats(video_id: str) -> dict:
    """
    Returns view, like, and comment counts for a single video.
    """
    youtube = get_authenticated_service()

    response = youtube.videos().list(
        part="statistics,snippet",
        id=video_id,
    ).execute()

    if not response.get("items"):
        raise ValueError(f"No video found with ID: {video_id}")

    item = response["items"][0]
    stats = item["statistics"]

    return {
        "title": item["snippet"]["title"],
        "views": stats.get("viewCount"),
        "likes": stats.get("likeCount"),
        "comments": stats.get("commentCount"),
    }
