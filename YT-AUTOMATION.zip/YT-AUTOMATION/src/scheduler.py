"""
scheduler.py
------------
Provides simple job scheduling so uploads can be queued to run
at a specific future time (e.g. every day at 6 PM) using the
`schedule` library.
"""

import time

import schedule

from src.uploader import upload_video


def schedule_upload(file_path, title, description, tags, run_at="18:00"):
    """
    Schedules a video upload to run once, at the given time (24h HH:MM format).

    Args:
        file_path (str): Path to the video file.
        title (str): Video title.
        description (str): Video description.
        tags (list[str]): SEO tags.
        run_at (str): Time of day to trigger the upload, e.g. "18:00".
    """

    def job():
        upload_video(file_path, title, description, tags)
        return schedule.CancelJob  # run once, then remove the job

    schedule.every().day.at(run_at).do(job)
    print(f"Upload scheduled for {run_at}. Waiting...")

    while schedule.jobs:
        schedule.run_pending()
        time.sleep(30)
