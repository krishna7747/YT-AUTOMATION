"""
main.py
-------
Entry point for the YT-AUTOMATION toolkit.
Presents a simple command-line menu to run each automation task:
upload a video, generate metadata, schedule an upload, or check analytics.
"""

from src.metadata_generator import generate_metadata
from src.uploader import upload_video
from src.scheduler import schedule_upload
from src.analytics import get_channel_stats, get_video_stats

import config


def menu():
    print("\n=== YT-AUTOMATION ===")
    print("1. Upload a video now")
    print("2. Generate metadata only")
    print("3. Schedule an upload")
    print("4. Get channel stats")
    print("5. Get video stats")
    print("0. Exit")
    return input("Choose an option: ").strip()


def main():
    while True:
        choice = menu()

        if choice == "1":
            file_path = input("Video file path: ").strip()
            topic = input("Video topic: ").strip()
            keywords = input("Keywords (comma-separated): ").split(",")
            meta = generate_metadata(topic, [k.strip() for k in keywords])
            upload_video(file_path, meta["title"], meta["description"], meta["tags"])

        elif choice == "2":
            topic = input("Video topic: ").strip()
            keywords = input("Keywords (comma-separated): ").split(",")
            meta = generate_metadata(topic, [k.strip() for k in keywords])
            print("\n--- Generated Metadata ---")
            print(f"Title: {meta['title']}")
            print(f"Description:\n{meta['description']}")
            print(f"Tags: {meta['tags']}")

        elif choice == "3":
            file_path = input("Video file path: ").strip()
            topic = input("Video topic: ").strip()
            keywords = input("Keywords (comma-separated): ").split(",")
            run_at = input("Run at (HH:MM, 24h): ").strip()
            meta = generate_metadata(topic, [k.strip() for k in keywords])
            schedule_upload(file_path, meta["title"], meta["description"], meta["tags"], run_at)

        elif choice == "4":
            channel_id = input("Channel ID: ").strip()
            print(get_channel_stats(channel_id))

        elif choice == "5":
            video_id = input("Video ID: ").strip()
            print(get_video_stats(video_id))

        elif choice == "0":
            print("Goodbye!")
            break

        else:
            print("Invalid option, try again.")


if __name__ == "__main__":
    main()
