# YT-AUTOMATION 🎬🤖

A Python-based toolkit to automate repetitive YouTube channel management tasks —
video uploading, metadata (title/description/tags) generation, upload scheduling,
and channel analytics reporting — using the official **YouTube Data API v3**.

---

## ✨ Features

- **Automated Video Upload** — Upload videos to your channel directly from a script
  instead of the YouTube Studio UI.
- **Metadata Generator** — Auto-generate SEO-friendly titles, descriptions, and tags
  from a simple template + keyword list.
- **Upload Scheduler** — Queue videos to publish at specific future date/times.
- **Channel Analytics** — Fetch views, likes, subscriber count, and watch-time stats
  for your channel or a specific video.
- **OAuth2 Authentication** — Secure Google account login flow, token cached locally
  so you don't have to log in every run.

---

## 📁 Project Structure

```
YT-AUTOMATION/
│
├── main.py                     # Entry point — CLI menu to run any automation task
├── requirements.txt            # Python dependencies
├── config.example.py           # Sample config (rename to config.py and fill in your keys)
├── .gitignore
│
└── src/
    ├── __init__.py
    ├── auth.py                 # Handles Google OAuth2 authentication
    ├── uploader.py              # Uploads a video file + metadata to YouTube
    ├── metadata_generator.py    # Generates title/description/tags automatically
    ├── scheduler.py             # Schedules videos for future publishing
    └── analytics.py             # Fetches channel/video analytics
```

---

## ⚙️ Setup

1. **Clone this repository**
   ```bash
   git clone https://github.com/krishna7747/YT-AUTOMATION.git
   cd YT-AUTOMATION
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Get YouTube Data API credentials**
   - Go to [Google Cloud Console](https://console.cloud.google.com/)
   - Create a project → Enable **YouTube Data API v3**
   - Create OAuth 2.0 credentials → download `client_secret.json`
   - Place it in the project root folder

4. **Configure**
   ```bash
   cp config.example.py config.py
   ```
   Edit `config.py` with your channel details and default upload settings.

5. **Run**
   ```bash
   python main.py
   ```

---

## 🚀 Usage Example

```python
from src.uploader import upload_video
from src.metadata_generator import generate_metadata

metadata = generate_metadata(
    topic="Python Automation Tutorial",
    keywords=["python", "automation", "coding"]
)

upload_video(
    file_path="videos/tutorial_01.mp4",
    title=metadata["title"],
    description=metadata["description"],
    tags=metadata["tags"],
    privacy_status="private"
)
```

---

## 🛣️ Roadmap

- [ ] Auto thumbnail generation using AI
- [ ] Auto-comment reply bot
- [ ] Multi-channel support
- [ ] Discord/Telegram upload notifications

---

## ⚠️ Disclaimer

This project uses the official YouTube Data API and must comply with
[YouTube API Terms of Service](https://developers.google.com/youtube/terms/api-services-terms-of-service).
Do not use it for spam, fake engagement, or ToS-violating automation.

---

## 📄 License

MIT License — free to use and modify.
